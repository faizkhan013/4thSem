package Assignment4;

import java.util.HashMap;

public class DictionaryExample {

    public static void main(String[] args) {

        HashMap<String, String> dictionary = new HashMap<>();

        dictionary.put("Java", "A high-level programming language");
        dictionary.put("Python", "A high-level interpreted language");
        dictionary.put("HashMap", "A data structure to strore key-value pairs");

        System.out.println("Defination of Java: " + dictionary.get("Java"));
        System.out.println("Defination of Python: " + dictionary.get("Python"));

        if (dictionary.containsKey("C++")) {
            System.out.println("Defination of C++ " + dictionary.get("C++"));
        }
        else {
            System.out.println("C++ is not in the dictionary.");

            dictionary.remove("HashMap");

            System.out.println("\nAfter removing 'HashMap':");
            System.out.println("Dictionary size: " + dictionary.size());
            System.out.println("\nAll dictionary entries:");

            for (String key : dictionary.keySet()) {
                System.out.println(key + ": " + dictionary.get(key));
            }

        }
    }
}
