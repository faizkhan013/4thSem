package Assignment4;

import java.security.Key;

class HashTableLP {
    private static final int EMPTY_VALUE = -1;
    private static final int DELETED_VALUE = -2;
    private static final int FILLED_VALUE = 0;

    private int tableSize;
    private int[] key;
    private int[] Flag;
    private int[] Value;

    public HashTableLP(int size) {
        this.tableSize = size;
        key = new int[tableSize];
        Value = new int[tableSize];
        Flag = new int[tableSize];

        for (int i = 0; i < tableSize; i++) {
            Flag[i] = EMPTY_VALUE;
        }
    }

    private int computeHash(int key) {
        return key % tableSize;
    }

    private int resolveFun(int index) {
        return (index + 1) % tableSize;
    }

    public boolean add(int get, int value) {
        int index = computeHash(key);
        for(int i=0;i<tableSize;i++){
            if(Flag[index]!=FILLED_VALUE){
                Key[index]= key;
                Value[index]= value;
                Flag[index]= FILLED_VALUE;
                return true;
            } else if (Key[index]==key) {
                value[index]=value;
                return false;
            }
            index = resolveFun(index);
        }
        System.out.println("Hash table is full!");
        return false;
    }
    public boolean find(int key){
        int index= computeHash(key);
        for (int i=0;i<tableSize && Flag[index]!EMPTY_VALUE;i++){
            if(Flag[index]==FILLED_VALUE && Key[index]==key){
                Flag[index]=DELETED_VALUE;
                return true;
            }
            index= resolveFun(index);
        }
        return false;
    }

    public void print(){
        for(int i=0;i<tableSize;i++){
            if (Flag[i]==FILLED_VALUE){
                System.out.println("Index"+i+":Key="+Key[i]+",Value ="+Value[i]);
            } else if (Flag[i]==DELETED_VALUE) {
                System.out.println("Index"+i+":Deleted");
            }
            else {
                System.out.println("Index"+i+":Empty");
            }
        }
    }

    public static void main(String[] args) {
        HashTableLP ht = new HashTableLP(5);
        ht.add(1,12);
        ht.add(15,14);
        ht.add(7,19);
        ht.add(0,2);
        ht.print();
        System.out.println("Find key 2"+ ht.find(2));
        System.out.println("Get key 2"+ ht.get(3));
        ht.remove(2);
    }
}


