package Assignment3;

// Implement Matrix Chain Multiplication
public class Matrix_Multiplication {
    public static int matrixChain(int[] d) {
        int n = d.length - 1;
        int[][] m = new int[n][n];

        for (int length = 2; length <= n; length++) {
            for (int i = 0; i < n - length + 1; i++) {
                int j = i + length - 1;
                m[i][j] = Integer.MAX_VALUE;
                for (int k = i; k < j; k++) {
                    int q = m[i][k] + m[k + 1][j] + d[i] * d[k + 1] * d[j + 1];
                    if (q < m[i][j]) {
                        m[i][j] = q;
                    }
                }
            }
        }
        return m[0][n - 1];
    }

    public static void main(String[] args) {
        int[] d = {3, 5, 1, 5, 10, 2, 5};

        int result = matrixChain(d);
        System.out.println("Minimum number of scalar multiplications: " + result);
    }
}
