package Practice;

public class Q4 {
    public static void main(String[] args) {
        String input = "madam";


        long startTime = System.nanoTime();
        boolean isPalindromeSB = isPalindromeUsingBuffer(new StringBuffer(input));
        long endTime = System.nanoTime();
        long stringBufferTime = endTime - startTime;


        startTime = System.nanoTime();
        boolean isPalindromeSBld = isPalindromeUsingBuilder(new StringBuilder(input));
        endTime = System.nanoTime();
        long stringBuilderTime = endTime - startTime;

        System.out.println("Using StringBuffer, palindrome? " + isPalindromeSB);
        System.out.println("Time taken with StringBuffer: " + stringBufferTime + " nanoseconds");

        System.out.println("Using StringBuilder, palindrome? " + isPalindromeSBld);
        System.out.println("Time taken with StringBuilder: " + stringBuilderTime + " nanoseconds");
    }

    public static boolean isPalindromeUsingBuffer(StringBuffer sb) {
        StringBuffer reversed = sb.reverse();
        return sb.toString().equals(reversed.toString());
    }

    public static boolean isPalindromeUsingBuilder(StringBuilder sbld) {
        StringBuilder reversed = sbld.reverse();
        return sbld.toString().equals(reversed.toString());
    }
}

