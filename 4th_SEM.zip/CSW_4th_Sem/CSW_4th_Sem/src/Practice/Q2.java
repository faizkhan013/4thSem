package Practice;

public class Q2 {
    public static void main(String[] args) {
        String str = "Hello";
        StringBuffer ob = new StringBuffer("Hello");
        StringBuilder obj = new StringBuilder("Hello");

        printReverse(str);
        printReverse(ob);
        printReverse(obj);
    }

    public static void printReverse(CharSequence cs) {
        System.out.println("Reversed: " + cs.toString());
        System.out.println("Reversed characters:");
        for (int i = cs.length() - 1; i >= 0; i--) {
            System.out.print(cs.charAt(i));
        }
        System.out.println();
    }
}

