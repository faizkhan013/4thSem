package Practice;

public class Q1 {
    public static void main(String[] args) {

        long startTime = System.nanoTime();
        String str = "";
        for (int i = 0; i < 100000; i++) {
            str += "A";
        }
        long endTime = System.nanoTime();
        long stringTime = endTime - startTime;


        startTime = System.nanoTime();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 100000; i++) {
            sb.append("A");
        }
        endTime = System.nanoTime();
        long stringBufferTime = endTime - startTime;

        System.out.println("Time taken by String: " + stringTime + " nanoseconds");
        System.out.println("Time taken by StringBuffer: " + stringBufferTime + " nanoseconds");
    }
}

