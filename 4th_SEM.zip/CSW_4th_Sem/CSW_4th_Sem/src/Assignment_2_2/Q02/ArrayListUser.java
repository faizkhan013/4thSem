package Assignment_2_2.Q02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ArrayListUser {
    public static void main(String[] args) {
        ArrayList<User> users = new ArrayList<>();
        users.add(new User("Ayan", 30));
        users.add(new User("Bijoy", 25));
        users.add(new User("Chayan", 35));
        users.add(new User("Dipayan", 28));
        users.add(new User("Prasun", 22));
        System.out.println("Original List of Users:");
        for (User user : users) {
            System.out.println(user);
        }
        Collections.sort(users, Comparator.comparingInt(User::getAge));
        System.out.println("\nSorted List of Users by Age:");
        for (User user : users) {
            System.out.println(user);
        }
    }
}
