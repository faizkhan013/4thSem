package Assignment_2_2.Q09;

import java.util.HashSet;

public class RepeatingIntegers {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 3, 2, 6, 7, 1};
        HashSet<Integer> seen = new HashSet<>();
        HashSet<Integer> repeating = new HashSet<>();
        for (int num : arr) {
            if (seen.contains(num)) {
                repeating.add(num);
            } else {
                seen.add(num);
            }
        }
        System.out.println("Repeating integers in the array: " + repeating);
    }
}
