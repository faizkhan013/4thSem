package Assignment_2_2.Q01;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Pair<String, Integer>> pairs = new ArrayList<>();
        pairs.add(new Pair<>("ABC", 1));
        pairs.add(new Pair<>("DEF", 2));
        pairs.add(new Pair<>("PQR", 3));
        for (Pair<String, Integer> pair : pairs) {
            System.out.println("Key: " + pair.getKey() + ", Value: " + pair.getValue());
        }
    }
}
