package Assignment_2_2.Q10;

import java.util.HashMap;

public class SmallestMissingNumber {
    public static void main(String[] args) {
        int[] arr = {3, 7, 1, 2, 8, 4, 5};
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int num : arr) {
            map.put(num, 1);
        }
        int missingNo = -1;
        for (int i = 1; i <= 10; i++) {
            if (!map.containsKey(i)) {
                missingNo = i;
                break;
            }
        }
        if (missingNo != -1) {
            System.out.println("The smallest positive number missing in the array is: " + missingNo);
        } else {
            System.out.println("No positive number is missing in the range 1 to 10.");
        }
    }
}
