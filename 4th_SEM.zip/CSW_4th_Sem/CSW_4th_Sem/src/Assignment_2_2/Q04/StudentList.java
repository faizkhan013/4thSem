package Assignment_2_2.Q04;

import java.util.LinkedList;
import java.util.Scanner;

public class StudentList {
    public static void main(String[] args) {
        LinkedList<Student> studentList = new LinkedList<>();
        Scanner sc = new Scanner(System.in);
        studentList.add(new Student("Mohana", 20, 85.5));
        studentList.add(new Student("Upasana", 21, 90.0));
        studentList.add(new Student("Jisha", 22, 78.0));
        System.out.println("List of students:");
        displayStudents(studentList);
        System.out.println("\nEnter student details to search:");
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Age: ");
        int age = sc.nextInt();
        System.out.print("Mark: ");
        double mark = sc.nextDouble();
        sc.nextLine();
        Student searchStudent = new Student(name, age, mark);
        boolean exists = studentList.contains(searchStudent);
        System.out.println("Search based on content comparison: " + exists);
        System.out.println("\nEnter student details to remove:");
        System.out.print("Name: ");
        String removeName = sc.nextLine();
        System.out.print("Age: ");
        int removeAge = sc.nextInt();
        System.out.print("Mark: ");
        double removeMark = sc.nextDouble();
        sc.nextLine();
        Student removeStudent = new Student(removeName, removeAge, removeMark);
        if (studentList.remove(removeStudent)) {
            System.out.println("Student removed successfully.");
        } else {
            System.out.println("Student not found.");
        }
        System.out.println("\nNumber of students in the list: " + studentList.size());
        System.out.println("\nUpdated list of students:");
        displayStudents(studentList);
        sc.close();
    }

    private static void displayStudents(LinkedList<Student> studentList) {
        for (Student student : studentList) {
            System.out.println(student);
        }
    }
}
