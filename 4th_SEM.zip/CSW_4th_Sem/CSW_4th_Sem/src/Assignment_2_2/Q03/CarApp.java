package Assignment_2_2.Q03;

import java.util.ArrayList;
import java.util.Collections;

public class CarApp {
    public static void main(String[] args) {
        ArrayList<Car> cars = new ArrayList<>();
        cars.add(new Car(2024, "Creta", 25));
        cars.add(new Car(2020, "Scorpio", 16));
        cars.add(new Car(2023, "Innova", 8));
        cars.add(new Car(2021, "Baleno", 72));
        cars.add(new Car(2022, "Nexon", 48));
        Collections.sort(cars);
        System.out.println("Sorted list of Car objects based on stock:");
        for (Car car : cars) {
            System.out.println(car);
        }
    }
}
