package Assignment_2_2.Q03;

public class Car implements Comparable<Car> {
    private int modelNo;
    private String name;
    private int stock;

    public Car(int modelNo, String name, int stock) {
        this.modelNo = modelNo;
        this.name = name;
        this.stock = stock;
    }

    public int getModelNo() {
        return modelNo;
    }

    public String getName() {
        return name;
    }

    public int getStock() {
        return stock;
    }

    public int compareTo(Car c) {
        return Integer.compare(this.stock, c.stock);
    }

    public String toString() {
        return modelNo + " " + name + " " + stock;
    }
}
