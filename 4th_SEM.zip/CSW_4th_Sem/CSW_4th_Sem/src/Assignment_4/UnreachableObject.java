package Assignment_4;
public class UnreachableObject {
    String name;
    public UnreachableObject(String name) {
        this.name = name;
        System.out.println("Object created " + name);
    }
    public void show() {
        UnreachableObject obj1 = new UnreachableObject("Object1");
        obj1.display();
    }
    public void display() {
        UnreachableObject obj2 = new UnreachableObject("Object2");
        obj2 = null;
        System.gc();
    }
    public void finalize() {
        System.out.println("Garbage collection invoked for object: " + name);
    }
    public static void main(String[] args) {
        UnreachableObject obj = new UnreachableObject("MainObject");
        obj.show();
        System.gc();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}