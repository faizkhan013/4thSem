package Assignment_4;


    public class MyClass {
        private int intValue;
        private double doubleValue;

        public MyClass(int intValue, double doubleValue) {
            this.intValue = intValue;
            this.doubleValue = doubleValue;
        }

        public void setIntValue(int intValue) {
            this.intValue = intValue;
        }

        public void setDoubleValue(double doubleValue) {
            this.doubleValue = doubleValue;
        }

        public void updateValues(int intValue, double doubleValue) {
            this.intValue = intValue;
            this.doubleValue = doubleValue;
        }

        public void displayValues() {
            System.out.println("Integer Value: " + this.intValue + ", Double Value: " + this.doubleValue);
        }

        public static void main(String[] args) {
            Runtime runtime = Runtime.getRuntime();

            long beforeMemory = runtime.totalMemory() - runtime.freeMemory();
            System.out.println("Memory used before object creation: " + beforeMemory + " bytes");

            MyClass obj1 = new MyClass(10, 20.5);
            MyClass obj2 = new MyClass(30, 40.5);

            obj1.displayValues();
            obj2.displayValues();

            obj1.setIntValue(100);
            obj1.setDoubleValue(200.5);
            obj2.updateValues(300, 400.5);

            obj1.displayValues();
            obj2.displayValues();

            long afterMemory = runtime.totalMemory() - runtime.freeMemory();
            System.out.println("Memory used after object creation and updates: " + afterMemory + " bytes");

            obj1 = null;
            obj2 = null;

            System.gc();

            long afterGC = runtime.totalMemory() - runtime.freeMemory();
            System.out.println("Memory used after garbage collection: " + afterGC + " bytes");
        }
    }


