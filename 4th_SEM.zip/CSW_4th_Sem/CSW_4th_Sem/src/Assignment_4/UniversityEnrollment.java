package Assignment_4;
class Student {
    String name;
    String course;
    public Student(String name, String course) {
        this.name = name;
        this.course = course;
    }
    public void showDetails() {
        System.out.println("Name: " + name);
        System.out.println("Course: " + course);
    }
    public void finalize() {
        System.out.println(name + " object is being garbage collected.");
    }
}
public class UniversityEnrollment {
    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        System.out.println("Memory before student creation: " + runtime.freeMemory() + " bytes");
        Student student1 = new Student("Alice", "Computer Science");
        Student student2 = new Student("Bob", "Electrical Engineering");
        student1.showDetails();
        student2.showDetails();
        student1 = null;
        student2 = null;
        System.gc();
        System.out.println("Memory after student creation and GC request: " + runtime.freeMemory() + " bytes");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
