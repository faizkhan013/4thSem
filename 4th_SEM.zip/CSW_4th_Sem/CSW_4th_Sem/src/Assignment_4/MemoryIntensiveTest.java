package Assignment_4;
import java.util.ArrayList;
import java.util.List;
class MemoryIntensiveObject {
    int[] data;
    public MemoryIntensiveObject(int size) {
        this.data = new int[size];
    }
}
public class MemoryIntensiveTest {
    public static void main(String[] args) {
        List<MemoryIntensiveObject> objects = new ArrayList<>();
        printMemoryDetails("Initial Memory");
        for (int i = 0; i < 100; i++) {
            objects.add(new MemoryIntensiveObject(10000));
            if (i % 10 == 0) {
                printMemoryDetails("After creating " + (i + 1) + " objects");
            }
        }
        objects.clear();
        printMemoryDetails("After clearing the list");
        System.gc();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        printMemoryDetails("After Garbage Collection");
    }
    private static void printMemoryDetails(String message) {
        Runtime runtime = Runtime.getRuntime();
        long totalMemory = runtime.totalMemory() / (1024 * 1024);
        long freeMemory = runtime.freeMemory() / (1024 * 1024);
        long usedMemory = totalMemory - freeMemory;

        System.out.printf("%s: Total Memory: %d MB, Free Memory: %d MB, Used Memory: %d MB%n",
                message, totalMemory, freeMemory, usedMemory);
    }
}
