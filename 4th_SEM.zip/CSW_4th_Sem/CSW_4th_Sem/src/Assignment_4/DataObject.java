package Assignment_4;
public class DataObject {
    int intValue;
    double doubleValue;
    public DataObject(int intValue, double doubleValue) {
        this.intValue = intValue;
        this.doubleValue = doubleValue;
    }
    public void setIntValue(int intValue) {
        this.intValue = intValue;
    }
    public void setDoubleValue(double doubleValue) {
        this.doubleValue = doubleValue;
    }
    public void updateValues(int newIntValue, double newDoubleValue) {
        this.intValue = newIntValue;
        this.doubleValue = newDoubleValue;
    }
    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        long beforeMemory = runtime.totalMemory() - runtime.freeMemory();
        DataObject obj1 = new DataObject(10, 20.5);
        DataObject obj2 = new DataObject(30, 40.75);
        obj1.setIntValue(100);
        obj1.setDoubleValue(200.5);
        obj2.updateValues(500, 1000.5);
        long afterMemory = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Memory used before making objects unreachable: " + (afterMemory - beforeMemory));
        obj1 = null;
        obj2 = null;
        System.gc();
        long finalMemory = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Memory used after making objects unreachable: " + (finalMemory - beforeMemory));
    }
}
