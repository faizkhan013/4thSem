package Assignment_4;
public class NullifiedReference {
    private String name;
    public NullifiedReference(String name) {
        this.name = name;
    }
    public void finalize() {
        System.out.println(name + " Object Garbage Collected");
    }
    public static void main(String[] args) {
        NullifiedReference ref = new NullifiedReference("Test Object");
        System.out.println("Object Created " + ref.name );
        ref = null;
        System.gc();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}