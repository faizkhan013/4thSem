package Assignment_4;
public class ReassigningReference {
    private String name;
    public ReassigningReference(String name) {
        this.name = name;
    }
    public void finalize() throws Throwable {
        System.out.println(name + " garbage collected!");
    }
    public static void main(String[] args) {
        ReassigningReference obj1 = new ReassigningReference("Object 1");
        ReassigningReference obj2 = new ReassigningReference("Object 2");
        obj1 = obj2;
        System.gc();
        try {
            Thread.sleep(1000); // Sleep for 1 second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}