package Assignment_1.Q10;

public class MainEnrollApp {
    public static void main(String[] args) {
        Student student1 = new Student();
        student1.setStudentId("S001");
        student1.setName("ABC");
        Student student2 = new Student();
        student2.setStudentId("S002");
        student2.setName("DEF");
        Student student3 = new Student();
        student3.setStudentId("S003");
        student3.setName("PQR");
        Course course1 = new Course(2);
        course1.setCourseId("C001");
        course1.setCourseName("Mathematics");
        Course course2 = new Course(2);
        course2.setCourseId("C002");
        course2.setCourseName("Physics");
        Enrollment enrollmentSystem = new Enrollment();
        enrollmentSystem.enrollStudent(student1, course1);
        enrollmentSystem.enrollStudent(student2, course1);
        enrollmentSystem.enrollStudent(student3, course1);
        enrollmentSystem.enrollStudent(student1, course2);
        enrollmentSystem.displayEnrollmentDetails(course1);
        enrollmentSystem.displayEnrollmentDetails(course2);
        enrollmentSystem.dropStudent(student1, course1);
        enrollmentSystem.displayEnrollmentDetails(course1);
    }
}
