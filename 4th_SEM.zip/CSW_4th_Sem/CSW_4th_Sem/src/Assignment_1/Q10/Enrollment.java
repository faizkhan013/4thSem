package Assignment_1.Q10;

interface EnrollmentSystem {
    void enrollStudent(Student student, Course course);

    void dropStudent(Student student, Course course);

    void displayEnrollmentDetails(Course course);
}

public class Enrollment implements EnrollmentSystem {
    public void enrollStudent(Student student, Course course) {
        if (course.addStudent(student)) {
            System.out.println(student.getName() + " has been enrolled in " + course.getCourseName());
        } else {
            System.out.println("Enrollment failed: " + course.getCourseName() + " is full.");
        }
    }

    public void dropStudent(Student student, Course course) {
        if (course.removeStudent(student)) {
            System.out.println(student.getName() + " has been dropped from " + course.getCourseName());
        } else {
            System.out.println("Drop failed: " + student.getName() + " is not enrolled in " + course.getCourseName());
        }
    }

    public void displayEnrollmentDetails(Course course) {
        System.out.println("Enrollment details for " + course.getCourseName() + ":");
        for (int i = 0; i < course.getStudentCount(); i++) {
            Student student = course.getEnrolledStudents()[i];
            if (student != null) {
                System.out.println("- " + student.getName() + " (ID: " + student.getStudentId() + ")");
            }
        }
    }
}
