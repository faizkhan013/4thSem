package Assignment_1.Q10;

public class Course {
    private String courseId;
    private String courseName;
    private Student[] enrolledStudents;
    private int studentCount;

    public Course(int maxStudents) {
        this.enrolledStudents = new Student[maxStudents];
        this.studentCount = 0;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Student[] getEnrolledStudents() {
        return enrolledStudents;
    }

    public int getStudentCount() {
        return studentCount;
    }

    public boolean addStudent(Student student) {
        if (studentCount < enrolledStudents.length) {
            enrolledStudents[studentCount++] = student;
            return true;
        }
        return false;
    }

    public boolean removeStudent(Student student) {
        for (int i = 0; i < studentCount; i++) {
            if (enrolledStudents[i].equals(student)) {
                enrolledStudents[i] = enrolledStudents[studentCount - 1];
                enrolledStudents[--studentCount] = null;
                return true;
            }
        }
        return false;
    }
}

