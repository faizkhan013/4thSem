package Assignment_1.Q01;

public class CarTester {
    public static void main(String[] args) {
        Car myCar1 = new Car("Toyota", "Urban Cruiser");
        Car myCar2 = new Car(null, null);
        System.out.println("Initial details of myCar1:");
        myCar1.printDetails();
        System.out.println();
        System.out.println("Initial details of myCar2:");
        myCar2.printDetails();
        myCar2.setMake("Maruti Suzuki");
        myCar2.setModel("Fronx");
        System.out.println();
        System.out.println("Updated details of myCar2:");
        myCar2.printDetails();
    }
}
