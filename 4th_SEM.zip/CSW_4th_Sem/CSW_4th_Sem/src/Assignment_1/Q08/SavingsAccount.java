package Assignment_1.Q08;

public class SavingsAccount extends Account {
    private double interestRate;

    public SavingsAccount(String accountNumber, double interestRate) {
        super(accountNumber);
        this.interestRate = interestRate;
    }

    public void deposit(double amount) {
        double interest = (getBalance() + amount) * (interestRate / 100);
        setBalance(getBalance() + amount + interest);
        System.out.println("Deposited: " + amount + ", Interest: " + interest + ", New Balance: " + getBalance());
    }

    public void withdraw(double amount) {
        if (amount <= getBalance()) {
            setBalance(getBalance() - amount);
            System.out.println("Withdrew: " + amount + ", New Balance: " + getBalance());
        } else {
            System.out.println("Insufficient balance for withdrawal.");
        }
    }
}
