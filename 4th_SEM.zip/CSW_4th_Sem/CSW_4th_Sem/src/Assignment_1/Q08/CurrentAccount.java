package Assignment_1.Q08;

public class CurrentAccount extends Account {
    private double overdraftLimit;

    public CurrentAccount(String accountNumber, double overdraftLimit) {
        super(accountNumber);
        this.overdraftLimit = overdraftLimit;
    }

    public void deposit(double amount) {
        setBalance(getBalance() + amount);
        System.out.println("Deposited: " + amount + ", New Balance: " + getBalance());
    }

    public void withdraw(double amount) {
        if (amount <= getBalance() + overdraftLimit) {
            setBalance(getBalance() - amount);
            System.out.println("Withdrew: " + amount + ", New Balance: " + getBalance());
        } else {
            System.out.println("Withdrawal exceeds overdraft limit.");
        }
    }
}
