package Assignment_1.Q08;

public class BankingApp {
    public static void main(String[] args) {
        Account savingsAccount = new SavingsAccount("SA123", 5.0);
        Account currentAccount = new CurrentAccount("CA456", 200.0);
        savingsAccount.deposit(1000);
        savingsAccount.withdraw(200);
        savingsAccount.withdraw(900);
        System.out.println();
        currentAccount.deposit(500);
        currentAccount.withdraw(600);
        currentAccount.withdraw(200);
    }
}
