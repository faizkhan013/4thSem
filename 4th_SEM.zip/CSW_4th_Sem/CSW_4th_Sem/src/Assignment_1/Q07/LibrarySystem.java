package Assignment_1.Q07;

public class LibrarySystem {
    public static void main(String[] args) {
        LibraryResource book = new Book("The Great Gatsby", "F. Scott Fitzgerald", 180);
        LibraryResource magazine = new Magazine("Time", "Henry Luce", "January 2025");
        LibraryResource dvd = new DVD("Inception", "Christopher Nolan", 148);
        book.displayDetails();
        System.out.println();
        magazine.displayDetails();
        System.out.println();
        dvd.displayDetails();
    }
}
