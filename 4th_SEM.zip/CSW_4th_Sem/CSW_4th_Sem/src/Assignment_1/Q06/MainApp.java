package Assignment_1.Q06;

public class MainApp {
    public static void main(String[] args) {
        College college1 = new College("ITER", "Bhubaneswar");
        College college2 = new College("IMS", "Bhubaneswar");
        Student student1 = new Student("S001", "Ajay", college1);
        Student student2 = new Student("S002", "Rajan", college2);
        student1.displayStudentInfo();
        System.out.println();
        student2.displayStudentInfo();
    }
}
