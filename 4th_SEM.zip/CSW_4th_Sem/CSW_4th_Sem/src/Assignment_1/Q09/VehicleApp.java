package Assignment_1.Q09;

public class VehicleApp {
    public static void main(String[] args) {
        Vehicle car = new Car();
        Vehicle bicycle = new Bicycle();
        car.accelerate();
        car.brake();
        bicycle.accelerate();
        bicycle.brake();
        Car myCar = new Car();
        myCar.accelerate(100);
        myCar.accelerate(100, 10);
        Bicycle myBicycle = new Bicycle();
        myBicycle.accelerate(20);
        myBicycle.accelerate(20, 5);
    }
}
