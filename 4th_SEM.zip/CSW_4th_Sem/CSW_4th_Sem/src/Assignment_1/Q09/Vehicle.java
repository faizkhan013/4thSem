package Assignment_1.Q09;

public interface Vehicle {
    void accelerate();

    void brake();
}
